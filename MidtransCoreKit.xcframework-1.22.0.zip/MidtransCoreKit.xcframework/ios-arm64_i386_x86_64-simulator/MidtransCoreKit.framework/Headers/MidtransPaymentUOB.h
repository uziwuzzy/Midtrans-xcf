//
//  MidtransPaymentUOB.h
//  MidtransCoreKit
//
//  Created by Muhammad Fauzi Masykur on 05/05/21.
//  Copyright © 2021 Midtrans. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MidtransPaymentDetails.h"

@interface MidtransPaymentUOB : NSObject <MidtransPaymentDetails>
@end
