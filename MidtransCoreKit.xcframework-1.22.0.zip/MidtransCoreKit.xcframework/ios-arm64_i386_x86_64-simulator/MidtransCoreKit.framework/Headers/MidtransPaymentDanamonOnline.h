//
//  MidtransPaymentDanamonOnline.h
//  MidtransCoreKit
//
//  Created by Vanbungkring on 9/27/17.
//  Copyright © 2017 Midtrans. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MidtransPaymentDetails.h"
@interface MidtransPaymentDanamonOnline : NSObject <MidtransPaymentDetails>

@end
