//
//  DataModels.h
//
//  Created by Ratna Kumalasari on 11/28/17
//  Copyright (c) 2017 __MyCompanyName__. All rights reserved.
//

#import "MIDGOPAYResponse.h"
